export default{
    accent: 'blue',
    primary: 'black'
}