export default{
    p: 12,
    w: 300,
    mw: 290,
    p2: 2,
    w2: '80%',
    mb: 20,
    mb2: 8,
}